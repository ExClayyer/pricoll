const Name = document.getElementById('name')
const surname = document.getElementById('surname')
const patronymic = document.getElementById('patronymic')
const login = document.getElementById('login')
const email = document.getElementById('email')
const password = document.getElementById('password')
const password_repeat = document.getElementById('password_repeat')
const rules = document.getElementById('rules')

let validClass = ['valid', 'invalid']

// .classList.toggle(validClass[1])

function validateNames(element) {
    let length = element.value.length;
    let NameValue = element.value.trim();
    const Approve = /^[а-яёА-ЯЁ\- ]+$/;
    const IsValid = length >= 2 && length <= 50 && Approve.test(NameValue)
    if (IsValid) {
        element.classList.remove(validClass[1])
        element.classList.add(validClass[0])
    } else {
        element.classList.remove(validClass[0])
        element.classList.add(validClass[1])
    }
}

function validateLogin(element) {
    let length = element.value.length;
    let NameValue = element.value.trim();
    const Approve = /^[a-zA-Z0-9\-]+$/;
    const IsValid = length >= 2 && length <= 50 && Approve.test(NameValue)
    if (IsValid) {
        element.classList.remove(validClass[1])
        element.classList.add(validClass[0])
    } else {
        element.classList.remove(validClass[0])
        element.classList.add(validClass[1])
    }
}
function validateEmail(element) {
    const value = element.value.trim();
    const Approve = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isValid = Approve.test(value) && value.length < 255;

    if (isValid) {
        element.classList.remove(validClass[1]);
        element.classList.add(validClass[0]);
    } else {
        element.classList.remove(validClass[0]);
        element.classList.add(validClass[1]);
    }
}

function validatePass(element){
    const length = element.value.length;
    const isValid = length >= 6;
    if (isValid) {
        element.classList.remove(validClass[1]);
        element.classList.add(validClass[0]);
    } else {
        element.classList.remove(validClass[0]);
        element.classList.add(validClass[1]);
    }
}

function validatePassRepeat(element){
    const pass = password.value;
    const passRepeat = password_repeat.value;
    const isValid = passRepeat == pass ? true : false;
    if (isValid) {
        element.classList.remove(validClass[1]);
        element.classList.add(validClass[0]);
    } else {
        element.classList.remove(validClass[0]);
        element.classList.add(validClass[1]);
    }
}

function validateCheckbox(element) {
    const isChecked = element.checked;

    if (isChecked) {
        element.classList.remove(validClass[1]);
        element.classList.add(validClass[0]);
    } else {
        element.classList.remove(validClass[0]);
        element.classList.add(validClass[1]);
    }
}


Name.addEventListener('change', (e) => validateNames(e.target))
surname.addEventListener('change', (e) => validateNames(e.target))
patronymic.addEventListener('change', (e) => validateNames(e.target))
login.addEventListener('change', (e) => validateLogin(e.target))
email.addEventListener('change', (e) => validateEmail(e.target))
password.addEventListener('change', (e) => validatePass(e.target))
password_repeat.addEventListener('change', (e) => validatePassRepeat(e.target))
agreement.addEventListener('change', () => validateCheckbox(e.target));

